  document.addEventListener('DOMContentLoaded', function() {
    
    const sections = document.querySelectorAll('.about-section, .melons-section, .environment-section, .contact-section');
    let currentSection = 0;
    let isTransitioning = false;
      const sectionObserver = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting && !isTransitioning) {
                const section = entry.target;
                const sectionIndex = Array.from(sections).indexOf(section);
                
                if (sectionIndex !== currentSection) {
                    handleSectionTransition(currentSection, sectionIndex);
                    currentSection = sectionIndex;
                }
            }
        });
    }, {
        threshold: 0.5,
        rootMargin: '0px 0px -20% 0px'
    });
      sections.forEach(section => sectionObserver.observe(section));
      function handleSectionTransition(fromIndex, toIndex) {
        if (isTransitioning) return;
        
        isTransitioning = true;
        const fromSection = sections[fromIndex];
        const toSection = sections[toIndex];
          if (fromSection) {
            fromSection.classList.add('section-blur-transition', 'blurring');
        }
          if (toSection) {
            toSection.classList.add('section-blur-transition', 'clearing');
            toSection.classList.add('section-transitioning');
        }
          createTransitionParticles(toSection);
          setTimeout(() => {
            if (toSection) {
                toSection.classList.add('chromatic-transition', 'active');
            }
        }, 400);
          setTimeout(() => {
            sections.forEach(section => {
                section.classList.remove(
                    'section-blur-transition', 
                    'blurring', 
                    'clearing', 
                    'section-transitioning',
                    'chromatic-transition',
                    'active'
                );
            });
            isTransitioning = false;
        }, 2000);
    }
      function createTransitionParticles(section) {
        const particlesContainer = document.createElement('div');
        particlesContainer.className = 'transition-particles';
        section.appendChild(particlesContainer);
          for (let i = 0; i < 20; i++) {
            const particle = document.createElement('div');
            particle.className = 'transition-particle';
            particle.style.left = Math.random() * 100 + '%';
            particle.style.animationDelay = Math.random() * 2 + 's';
            particle.style.animationDuration = (Math.random() * 4 + 6) + 's';
            particlesContainer.appendChild(particle);
        }
          setTimeout(() => {
            if (particlesContainer.parentNode) {
                particlesContainer.parentNode.removeChild(particlesContainer);
            }
        }, 8000);
    }
      let scrollTimeout;
    window.addEventListener('scroll', function() {
          sections.forEach(section => {
            section.classList.add('color-morphing');
        });
          clearTimeout(scrollTimeout);
        scrollTimeout = setTimeout(() => {
            sections.forEach(section => {
                section.classList.remove('color-morphing');
            });
        }, 150);
    });
      function createImageOverlay(section, nextSection) {
        const overlay = document.createElement('div');
        overlay.className = 'section-image-overlay';
          const nextBg = window.getComputedStyle(nextSection).backgroundImage;
        overlay.style.backgroundImage = nextBg;
        
        section.appendChild(overlay);
          setTimeout(() => {
            overlay.classList.add('active');
        }, 100);
          setTimeout(() => {
            if (overlay.parentNode) {
                overlay.parentNode.removeChild(overlay);
            }
        }, 2000);
    }
      let lastScrollTop = 0;
    let scrollVelocity = 0;
    
    window.addEventListener('scroll', function() {
        const st = window.pageYOffset || document.documentElement.scrollTop;
        const currentTime = Date.now();
        
        scrollVelocity = Math.abs(st - lastScrollTop);
          if (scrollVelocity > 20) {
            sections.forEach(section => {
                section.style.filter = `blur(${Math.min(scrollVelocity / 10, 8)}px)`;
            });
              setTimeout(() => {
                sections.forEach(section => {
                    section.style.filter = 'blur(0px)';
                });
            }, 200);
        }
        
        lastScrollTop = st <= 0 ? 0 : st;
    });
      function applyTransitionGradients() {
          const aboutSection = document.querySelector('.about-section');
        if (aboutSection) {
            const transitionDiv = document.createElement('div');
            transitionDiv.className = 'about-to-melons-transition';
            transitionDiv.style.position = 'absolute';
            transitionDiv.style.bottom = '0';
            transitionDiv.style.left = '0';
            transitionDiv.style.width = '100%';
            transitionDiv.style.height = '200px';
            transitionDiv.style.zIndex = '5';
            transitionDiv.style.pointerEvents = 'none';
            aboutSection.appendChild(transitionDiv);
        }
          const melonsSection = document.querySelector('.melons-section');
        if (melonsSection) {
            const transitionDiv = document.createElement('div');
            transitionDiv.className = 'melons-to-environment-transition';
            transitionDiv.style.position = 'absolute';
            transitionDiv.style.bottom = '0';
            transitionDiv.style.left = '0';
            transitionDiv.style.width = '100%';
            transitionDiv.style.height = '200px';
            transitionDiv.style.zIndex = '5';
            transitionDiv.style.pointerEvents = 'none';
            melonsSection.appendChild(transitionDiv);
        }
          const environmentSection = document.querySelector('.environment-section');
        if (environmentSection) {
            const transitionDiv = document.createElement('div');
            transitionDiv.className = 'environment-to-contact-transition';
            transitionDiv.style.position = 'absolute';
            transitionDiv.style.bottom = '0';
            transitionDiv.style.left = '0';
            transitionDiv.style.width = '100%';
            transitionDiv.style.height = '200px';
            transitionDiv.style.zIndex = '5';
            transitionDiv.style.pointerEvents = 'none';
            environmentSection.appendChild(transitionDiv);
        }
    }
      setTimeout(applyTransitionGradients, 1000);
      function createWaveEffect(section) {
        const wave = document.createElement('div');
        wave.style.position = 'absolute';
        wave.style.bottom = '0';
        wave.style.left = '0';
        wave.style.width = '100%';
        wave.style.height = '100px';
        wave.style.background = `linear-gradient(
            90deg,
            transparent 0%,
            rgba(196, 154, 108, 0.3) 25%,
            rgba(196, 154, 108, 0.5) 50%,
            rgba(196, 154, 108, 0.3) 75%,
            transparent 100%
        )`;
        wave.style.zIndex = '6';
        wave.style.pointerEvents = 'none';
        wave.style.transform = 'translateX(-100%)';
        wave.style.transition = 'transform 2s ease-in-out';
        
        section.appendChild(wave);
          setTimeout(() => {
            wave.style.transform = 'translateX(100%)';
        }, 100);
          setTimeout(() => {
            if (wave.parentNode) {
                wave.parentNode.removeChild(wave);
            }
        }, 2200);
    }
      const waveObserver = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting && entry.intersectionRatio > 0.8) {
                createWaveEffect(entry.target);
            }
        });
    }, {
        threshold: 0.8
    });

    sections.forEach(section => waveObserver.observe(section));

    console.log('🌊 SMOOTH SECTION TRANSITIONS ACTIVATED! 🌊');
});