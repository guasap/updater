  document.addEventListener('DOMContentLoaded', function() {
    const heroSection = document.querySelector('.hero');
    const heroSubtitle = document.getElementById('heroSubtitle');
    const heroDots = document.querySelectorAll('.hero-dot');
    const heroPrev = document.getElementById('heroPrev');
    const heroNext = document.getElementById('heroNext');
    
    if (!heroSection || !heroSubtitle) return;
      const slides = [
        {
            image: 'url("images/imagen3.jpeg")',
            text: 'Cultivado con esmero<br>en el corazón del Parque Natural de El Hondo.'
        },
        {
            image: 'url("images/imagen18.jpeg',
            text: 'Sin prisas, sin químicos<br>y con el alma de la tierra.'
        },
        {
            image: 'url("images/imagen9.jpeg',
            text: 'Una joya artesanal<br>que no se encuentra en cualquier mesa.'
        },
        {
            image: 'url("images/imagen10.jpeg',
            text: 'Sino en la de quienes saben elegir<br>lo auténtico, lo fino.'
        },
        {
            image: 'url("images/imagen13.jpg',
            text: 'Lo que deja huella.<br>Eso es el Melón del Conde.'
        }
    ];
      let currentSlide = 0;
    let slideInterval;
    let isTransitioning = false;
    let autoPlayTimeout = null; // Para controlar el timeout de reanudar
      function initializeHero() {
        heroSection.style.backgroundImage = `linear-gradient(rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.4)), ${slides[0].image}`;
        heroSection.style.backgroundSize = 'cover';
        heroSection.style.backgroundPosition = 'center';
        heroSection.style.backgroundAttachment = 'fixed';
        heroSection.style.transition = 'background-image 1s ease-in-out';
          heroSubtitle.innerHTML = slides[0].text;
        heroSubtitle.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
    }
      function changeSlide(newIndex, direction = 'next') {
        if (isTransitioning || newIndex === currentSlide) return;
        isTransitioning = true;
          heroSubtitle.style.opacity = '0';
        heroSubtitle.style.transform = direction === 'next' ? 'translateX(-30px)' : 'translateX(30px)';
        
        setTimeout(() => {
              heroSection.style.backgroundImage = `linear-gradient(rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.4)), ${slides[newIndex].image}`;
              heroSubtitle.innerHTML = slides[newIndex].text;
              heroSubtitle.style.transform = direction === 'next' ? 'translateX(30px)' : 'translateX(-30px)';
            
            setTimeout(() => {
                heroSubtitle.style.opacity = '1';
                heroSubtitle.style.transform = 'translateX(0)';
                  updateDots(newIndex);
                currentSlide = newIndex;
                isTransitioning = false;
            }, 50);
        }, 300);
    }
      function updateDots(activeIndex) {
        heroDots.forEach((dot, index) => {
            dot.classList.toggle('active', index === activeIndex);
        });
    }
      function nextSlide() {
        const newIndex = (currentSlide + 1) % slides.length;
        changeSlide(newIndex, 'next');
    }
      function prevSlide() {
        const newIndex = currentSlide === 0 ? slides.length - 1 : currentSlide - 1;
        changeSlide(newIndex, 'prev');
    }
      function goToSlide(index) {
        if (index === currentSlide || isTransitioning) return;
        const direction = index > currentSlide ? 'next' : 'prev';
        changeSlide(index, direction);
    }    // Auto-play del slideshow mejorado
    function startAutoPlay() {
          clearInterval(slideInterval);
        clearTimeout(autoPlayTimeout);
        
        slideInterval = setInterval(nextSlide, 3000); // Cambiar cada 3 segundos
    }
    
    function stopAutoPlay() {
        clearInterval(slideInterval);
        clearTimeout(autoPlayTimeout);
    }
      function handleUserInteraction(callback) {
        if (isTransitioning) return; // No hacer nada si ya está en transición
        
        stopAutoPlay();
        callback();
          clearTimeout(autoPlayTimeout);
        autoPlayTimeout = setTimeout(() => {
            startAutoPlay();
        }, 8000);
    }
      if (heroNext) {
        heroNext.addEventListener('click', () => {
            handleUserInteraction(nextSlide);
        });
    }
    
    if (heroPrev) {
        heroPrev.addEventListener('click', () => {
            handleUserInteraction(prevSlide);
        });
    }
      heroDots.forEach((dot, index) => {
        dot.addEventListener('click', () => {
            handleUserInteraction(() => goToSlide(index));
        });
    });
      heroSection.addEventListener('mouseenter', stopAutoPlay);
    heroSection.addEventListener('mouseleave', () => {
        clearTimeout(autoPlayTimeout);
        autoPlayTimeout = setTimeout(startAutoPlay, 1000);
    });
      document.addEventListener('keydown', (e) => {
        if (e.key === 'ArrowLeft') {
            handleUserInteraction(prevSlide);
        } else if (e.key === 'ArrowRight') {
            handleUserInteraction(nextSlide);
        }
    });
      let touchStartX = 0;
    let touchEndX = 0;
      let mouseStartX = 0;
    let mouseEndX = 0;
    let isDragging = false;
    let dragIndicator = null;
      function createDragIndicator() {
        dragIndicator = document.createElement('div');
        dragIndicator.className = 'hero-drag-indicator';
        dragIndicator.innerHTML = '<i class="fas fa-hand-rock"></i>Arrastra para navegar';
        heroSection.appendChild(dragIndicator);
    }
      heroSection.addEventListener('mousedown', (e) => {
        if (e.button !== 0) return; // Solo botón izquierdo
        mouseStartX = e.clientX;
        isDragging = true;
        heroSection.classList.add('dragging');
        
        if (dragIndicator) {
            dragIndicator.classList.add('show');
        }
        
        e.preventDefault();
    });
    
    document.addEventListener('mousemove', (e) => {
        if (!isDragging) return;
        
        const currentX = e.clientX;
        const diff = currentX - mouseStartX;
          if (Math.abs(diff) > 10) {
            if (diff > 0) {
                heroSection.classList.add('drag-right');
                heroSection.classList.remove('drag-left');
            } else {
                heroSection.classList.add('drag-left');
                heroSection.classList.remove('drag-right');
            }
        }
    });
    
    document.addEventListener('mouseup', (e) => {
        if (!isDragging) return;
        
        mouseEndX = e.clientX;
        isDragging = false;
        heroSection.classList.remove('dragging', 'drag-left', 'drag-right');
        
        if (dragIndicator) {
            dragIndicator.classList.remove('show');
        }
        
        handleMouseDrag();
    });
      function handleMouseDrag() {
        const dragThreshold = 50;
        const diff = mouseStartX - mouseEndX;
        
        if (Math.abs(diff) > dragThreshold) {
            handleUserInteraction(() => {
                if (diff > 0) {
                    nextSlide(); // Drag left = next
                } else {
                    prevSlide(); // Drag right = prev
                }
            });
        }
    }
      heroSection.addEventListener('touchstart', (e) => {
        touchStartX = e.changedTouches[0].screenX;
    });
    
    heroSection.addEventListener('touchend', (e) => {
        touchEndX = e.changedTouches[0].screenX;
        handleSwipe();
    });
    
    function handleSwipe() {
        const swipeThreshold = 50;
        const diff = touchStartX - touchEndX;
        
        if (Math.abs(diff) > swipeThreshold) {
            handleUserInteraction(() => {
                if (diff > 0) {
                    nextSlide(); // Swipe left = next
                } else {
                    prevSlide(); // Swipe right = prev
                }
            });
        }
    }
      const preventDragElements = heroSection.querySelectorAll('.hero-nav-btn, .hero-dot, .cta-button');
    preventDragElements.forEach(element => {
        element.addEventListener('mousedown', (e) => {
            e.stopPropagation();
        });
    });
      initializeHero();
    createDragIndicator();
    setTimeout(startAutoPlay, 2000); // Iniciar auto-play después de 2s
      window.addEventListener('beforeunload', stopAutoPlay);
});