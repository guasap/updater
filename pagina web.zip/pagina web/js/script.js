  document.addEventListener('DOMContentLoaded', function() {
      const header = document.querySelector('.header');
    const menuToggle = document.querySelector('.menu-toggle');
    const sideNav = document.querySelector('.side-nav');
    const navOverlay = document.querySelector('.nav-overlay');
    const closeMenu = document.querySelector('.close-menu');
    const navLinks = document.querySelectorAll('.nav-menu a');
    let isMenuOpen = false;
    let lastScrollY = window.scrollY;
    let ticking = false;
    let scrollDirection = 'up';
      function updateHeader() {
        const currentScrollY = window.scrollY;
        const isMobile = window.innerWidth <= 840;
          if (currentScrollY > lastScrollY && currentScrollY > 100) {
            scrollDirection = 'down';
        } else if (currentScrollY < lastScrollY) {
            scrollDirection = 'up';
        }
          if (currentScrollY > 50) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
          if (isMobile) {
              header.classList.remove('hide');
              header.style.position = 'fixed';
            header.style.top = '0';
            header.style.transform = 'translateY(0)';
              header.style.background = 'linear-gradient(to bottom, rgba(0, 6, 32, 0.945) 0%, rgba(0, 0, 0, 0) 100%)';
            header.style.backdropFilter = 'blur(10px)';
        } else {
              if (currentScrollY > 200 && scrollDirection === 'down' && !isMenuOpen) {
                header.classList.add('hide');
            } else if (scrollDirection === 'up' || currentScrollY <= 100) {
                header.classList.remove('hide');
            }
              header.style.background = 'linear-gradient(to bottom, rgba(0, 6, 32, 0.945) 0%, rgba(0, 0, 0, 0) 100%)';
        }

        lastScrollY = currentScrollY;
        ticking = false;
    }
      function onScroll() {
        if (!ticking) {
            requestAnimationFrame(updateHeader);
            ticking = true;
        }
    }

    window.addEventListener('scroll', onScroll, { passive: true });
      function toggleMenu() {
        isMenuOpen = !isMenuOpen;
        
        if (isMenuOpen) {
            menuToggle.classList.add('active');
            sideNav.classList.add('active');
            navOverlay.classList.add('active');
            document.body.style.overflow = 'hidden';
            header.classList.remove('hide'); // Always show header when menu is open
            header.classList.add('menu-open'); // Add menu-open class
        } else {
            menuToggle.classList.remove('active');
            sideNav.classList.remove('active');
            navOverlay.classList.remove('active');
            document.body.style.overflow = '';
            header.classList.remove('menu-open'); // Remove menu-open class
        }
    }
      function closeMenuFunc() {
        isMenuOpen = false;
        menuToggle.classList.remove('active');
        sideNav.classList.remove('active');
        navOverlay.classList.remove('active');
        document.body.style.overflow = '';
        header.classList.remove('menu-open');
    }
      if (menuToggle) {
        menuToggle.addEventListener('click', toggleMenu);
    }
    if (closeMenu) {
        closeMenu.addEventListener('click', closeMenuFunc);
    }
    if (navOverlay) {
        navOverlay.addEventListener('click', closeMenuFunc);
    }
      navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            const targetSection = document.querySelector(targetId);
            
            closeMenuFunc();
            
            if (targetSection) {
                setTimeout(() => {
                    targetSection.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }, 400);
            }
        });
    });
      document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && isMenuOpen) {
            closeMenuFunc();
        }
    });
      const ctaButton = document.querySelector('.cta-button');
    const melonButton = document.querySelector('.melon-button');
    const sustainabilityButton = document.querySelector('.sustainability-button');
    
    if (ctaButton) {
        ctaButton.addEventListener('click', function() {
            document.querySelector('.about').scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        });
    }
    
    if (melonButton) {
        melonButton.addEventListener('click', function() {
            document.querySelector('.sustainability').scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        });
    }
    
    if (sustainabilityButton) {
        sustainabilityButton.addEventListener('click', function() {
            document.querySelector('.final-section').scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        });
    }
      const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -100px 0px'
    };

    const revealObserver = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('revealed');
                  if (entry.target.classList.contains('image-placeholder') || 
                    entry.target.classList.contains('nature-image')) {
                    setTimeout(() => {
                        entry.target.classList.add('loaded');
                    }, 200);
                }
                  revealObserver.unobserve(entry.target);
            }
        });
    }, observerOptions);
      const aboutText = document.querySelector('.about-text');
    const melonText = document.querySelector('.melon-text');
    const sustainabilityText = document.querySelector('.sustainability-text');
    const imagePlaceholder = document.querySelector('.image-placeholder');
    const natureImage = document.querySelector('.nature-image');
    const qualitySeal = document.querySelector('.quality-seal');

    if (aboutText) {
        aboutText.classList.add('smooth-reveal-left');
        revealObserver.observe(aboutText);
    }

    if (qualitySeal) {
        qualitySeal.classList.add('smooth-reveal-right');
        revealObserver.observe(qualitySeal);
    }

    if (melonText) {
        melonText.classList.add('smooth-reveal-left');
        revealObserver.observe(melonText);
    }

    if (imagePlaceholder) {
        imagePlaceholder.classList.add('smooth-reveal-right');
        revealObserver.observe(imagePlaceholder);
    }

    if (natureImage) {
        natureImage.classList.add('smooth-reveal-left');
        revealObserver.observe(natureImage);
    }

    if (sustainabilityText) {
        sustainabilityText.classList.add('smooth-reveal-right');
        revealObserver.observe(sustainabilityText);
    }
      const imageObserver = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('revealed');
                  if (entry.target.classList.contains('about-img') || 
                    entry.target.classList.contains('location-img') ||
                    entry.target.classList.contains('melon-img') ||
                    entry.target.classList.contains('nature-img')) {
                    setTimeout(() => {
                        entry.target.classList.add('loaded');
                    }, 200);
                }
                
                imageObserver.unobserve(entry.target);
            }
        });
    }, observerOptions);
      const realImages = document.querySelectorAll('.about-img, .location-img, .melon-img, .nature-img');
    realImages.forEach(img => {
        img.classList.add('smooth-reveal-image');
        imageObserver.observe(img);
    });
});
        } else {
            header.style.background = 'rgba(44, 62, 80, 0.95)';
            header.style.padding = '20px 0';
        }
        
        lastScrollTop = scrollTop;
    });
});
