document.addEventListener('DOMContentLoaded', function() {
    const navLinks = document.querySelectorAll('.nav-link[data-section]');
    const sections = document.querySelectorAll('section[id]');
      function updateActiveNav() {
        let current = '';
        const scrollPosition = window.scrollY + 200;
        
        if (window.scrollY < 200) {
            current = 'home';
        } else {
            sections.forEach(section => {
                const sectionTop = section.offsetTop;
                const sectionHeight = section.clientHeight;
                
                if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
                    current = section.getAttribute('id');
                }
            });
        }
        
        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('data-section') === current) {
                link.classList.add('active');
            }
        });
    }
      navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('data-section');
            let targetSection;
            
            if (targetId === 'home') {
                targetSection = document.querySelector('.hero');
            } else {
                targetSection = document.querySelector(`#${targetId}`);
            }
            
            if (targetSection) {
                  const sideNav = document.getElementById('sideNav');
                const navOverlay = document.querySelector('.nav-overlay');
                const menuToggle = document.getElementById('menuToggle');
                
                if (sideNav && sideNav.classList.contains('open')) {
                    sideNav.classList.remove('open');
                    if (navOverlay) navOverlay.classList.remove('active');
                    if (menuToggle) menuToggle.classList.remove('active');
                }
                
                targetSection.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
                
                navLinks.forEach(navLink => navLink.classList.remove('active'));
                this.classList.add('active');
            }
        });
    });
    
    window.addEventListener('scroll', updateActiveNav);
    setTimeout(updateActiveNav, 500);
      const scrollIndicator = document.querySelector('.scroll-indicator');
    if (scrollIndicator) {
        scrollIndicator.addEventListener('click', function() {
            const melonesSection = document.querySelector('#melones');
            if (melonesSection) {
                melonesSection.scrollIntoView({ 
                    behavior: 'smooth' 
                });
            }
        });
    }
});
