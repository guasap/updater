class MobileNavigation {
    constructor() {
        this.menuToggle = document.querySelector('.menu-toggle');
        this.sideNav = document.querySelector('.side-nav');
        this.navOverlay = document.querySelector('.nav-overlay');
        this.closeMenu = document.querySelector('.close-menu');
        this.navLinks = document.querySelectorAll('.nav-menu a');
        this.header = document.querySelector('.header');
        this.body = document.body;
        
        this.isMenuOpen = false;
        this.isPageTransitioning = false;
        
        this.init();
    }
    
    init() {
        this.setupEventListeners();
        this.createCloseButton();
        this.ensureMobileMenuStructure();
        console.log('Mobile Navigation initialized');
    }
    
    ensureMobileMenuStructure() {
          if (this.sideNav) {
            this.sideNav.style.background = 'linear-gradient(135deg, rgba(0, 0, 0, 0.97) 0%, rgba(20, 20, 20, 0.99) 50%, rgba(0, 0, 0, 0.97) 100%)';
        }
    }
    
    createCloseButton() {
        if (!this.closeMenu && this.sideNav) {
            const closeButton = document.createElement('button');
            closeButton.className = 'close-menu';
            closeButton.innerHTML = '<i class="fas fa-times"></i>';
            closeButton.setAttribute('aria-label', 'Cerrar menú');
            
            const navHeader = document.createElement('div');
            navHeader.className = 'side-nav-header';
            navHeader.appendChild(closeButton);
            
            this.sideNav.insertBefore(navHeader, this.sideNav.firstChild);
            this.closeMenu = closeButton;
        }
    }
    
    setupEventListeners() {
          if (this.menuToggle) {
            this.menuToggle.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                this.toggleMenu();
            });
            
            this.menuToggle.addEventListener('touchstart', (e) => {
                e.preventDefault();
                this.toggleMenu();
            }, { passive: false });
        }
          document.addEventListener('click', (e) => {
            if (e.target.closest('.close-menu')) {
                e.preventDefault();
                this.closeMenuFunc();
            }
        });
          if (this.navOverlay) {
            this.navOverlay.addEventListener('click', (e) => {
                e.preventDefault();
                this.closeMenuFunc();
            });
        }
          this.navLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                this.handleNavLinkClick(e, link);
            });
        });
          document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.isMenuOpen) {
                this.closeMenuFunc();
            }
        });
          window.addEventListener('resize', () => {
            if (window.innerWidth > 840 && this.isMenuOpen) {
                this.closeMenuFunc();
            }
        });
    }
    
    toggleMenu() {
        console.log('Toggling menu, current state:', this.isMenuOpen);
        
        this.isMenuOpen = !this.isMenuOpen;
        
        if (this.isMenuOpen) {
            this.openMenu();
        } else {
            this.closeMenuFunc();
        }
    }
    
    openMenu() {
        console.log('Opening mobile menu');
          this.body.style.overflow = 'hidden';
        this.body.style.position = 'fixed';
        this.body.style.top = `-${window.scrollY}px`;
        this.body.style.width = '100%';
          this.menuToggle?.classList.add('active');
        this.sideNav?.classList.add('active');
        this.navOverlay?.classList.add('active');
          this.header?.classList.remove('hide');
        this.header?.classList.add('menu-open');
          setTimeout(() => {
            this.animateMenuItems();
        }, 100);
    }
    
    closeMenuFunc() {
        console.log('Closing mobile menu');
        
        this.isMenuOpen = false;
          const scrollY = this.body.style.top;
          this.menuToggle?.classList.remove('active');
        this.sideNav?.classList.remove('active');
        this.navOverlay?.classList.remove('active');
        this.header?.classList.remove('menu-open');
          this.body.style.position = '';
        this.body.style.top = '';
        this.body.style.width = '';
        this.body.style.overflow = '';
          if (scrollY) {
            window.scrollTo(0, parseInt(scrollY || '0') * -1);
        }
          this.resetMenuItems();
    }
    
    animateMenuItems() {
        const menuItems = this.sideNav?.querySelectorAll('.nav-menu li');
        if (menuItems) {
            menuItems.forEach((item, index) => {
                setTimeout(() => {
                    item.classList.add('animate-in');
                }, index * 100);
            });
        }
    }
    
    resetMenuItems() {
        const menuItems = this.sideNav?.querySelectorAll('.nav-menu li');
        if (menuItems) {
            menuItems.forEach(item => {
                item.classList.remove('animate-in');
            });
        }
    }
    
    handleNavLinkClick(e, link) {
        const href = link.getAttribute('href');
        
        if (href && href.startsWith('#')) {
              e.preventDefault();
            const target = document.querySelector(href);
            if (target) {
                this.closeMenuFunc();
                setTimeout(() => {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }, 300);
            }
        } else if (href && !href.startsWith('http') && !this.isPageTransitioning) {
              e.preventDefault();
            this.isPageTransitioning = true;
            
            this.createPageTransition(() => {
                window.location.href = href;
            });
            
            this.closeMenuFunc();
        } else {
              this.closeMenuFunc();
        }
    }
    
    createPageTransition(callback) {
        const overlay = document.createElement('div');
        overlay.className = 'page-transition-overlay';
        
        const logo = document.createElement('div');
        logo.className = 'transition-logo';
        logo.innerHTML = '<img src="pajarraco.svg" alt="Loading..." style="width: 100%; height: 100%; filter: brightness(0) invert(1);">';
        
        overlay.appendChild(logo);
        this.body.appendChild(overlay);
          setTimeout(() => {
            overlay.classList.add('active');
        }, 50);
          setTimeout(() => {
            callback();
        }, 800);
    }
}
  document.addEventListener('DOMContentLoaded', () => {
    new MobileNavigation();
});
