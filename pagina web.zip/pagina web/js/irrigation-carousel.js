document.addEventListener('DOMContentLoaded', function() {
    const carousel = document.querySelector('.irrigation-carousel-inner');
    
    if (carousel) {
        let currentSlide = 0;
        const totalSlides = 3;
        const slideWidth = 33.333333; // Each slide is 33.333% wide
        
        function nextSlide() {
            currentSlide = (currentSlide + 1) % totalSlides;
            carousel.style.transform = `translateX(-${currentSlide * slideWidth}%)`;
        }
          carousel.style.transform = 'translateX(0%)';
          setInterval(nextSlide, 5000); // Change slide every 5 seconds
        
        console.log('Irrigation carousel initialized successfully');
    } else {
        console.log('Irrigation carousel element not found');
    }
});
