class MobileHeaderManager {
    constructor() {
        this.header = document.querySelector('.header');
        this.isMobile = window.innerWidth <= 840;
        this.init();
    }
    
    init() {
        this.setupMobileHeader();
        this.setupResizeListener();
        console.log('Mobile Header Manager initialized');
    }
    
    setupMobileHeader() {
        if (this.isMobile && this.header) {
              this.header.style.position = 'fixed';
            this.header.style.top = '0';
            this.header.style.left = '0';
            this.header.style.right = '0';
            this.header.style.transform = 'translateY(0)';
            this.header.style.zIndex = '1000';
              this.header.classList.remove('hide');
              this.observeHeaderChanges();
        }
    }
    
    observeHeaderChanges() {
        if (!this.isMobile) return;
          const observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                if (mutation.type === 'attributes' && mutation.attributeName === 'style') {
                      if (this.header.style.transform.includes('translateY(-')) {
                        this.header.style.transform = 'translateY(0)';
                    }
                }
                
                if (mutation.type === 'attributes' && mutation.attributeName === 'class') {
                      if (this.header.classList.contains('hide')) {
                        this.header.classList.remove('hide');
                    }
                }
            });
        });
        
        observer.observe(this.header, {
            attributes: true,
            attributeFilter: ['style', 'class']
        });
    }
    
    setupResizeListener() {
        window.addEventListener('resize', () => {
            const wasMobile = this.isMobile;
            this.isMobile = window.innerWidth <= 840;
            
            if (wasMode !== this.isMobile) {
                if (this.isMobile) {
                    this.setupMobileHeader();
                } else {
                      this.header.style.position = '';
                    this.header.style.transform = '';
                }
            }
        });
    }
}
  document.addEventListener('DOMContentLoaded', () => {
    new MobileHeaderManager();
});
