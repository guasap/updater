document.addEventListener('DOMContentLoaded', function() {
    const images = document.querySelectorAll('.melon-carousel-img');
    const lightbox = document.getElementById('melon-lightbox');
    const lightboxImg = document.getElementById('melon-lightbox-img');
    const closeBtn = document.querySelector('.melon-lightbox-close');

    images.forEach(img => {
        img.addEventListener('click', function() {
            lightbox.style.display = 'flex';
            lightboxImg.src = this.src;
            lightboxImg.alt = this.alt;
        });
    });

    closeBtn.addEventListener('click', function() {
        lightbox.style.display = 'none';
        lightboxImg.src = '';
    });

    lightbox.addEventListener('click', function(e) {
        if (e.target === lightbox) {
            lightbox.style.display = 'none';
            lightboxImg.src = '';
        }
    });

    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && lightbox.style.display === 'flex') {
            lightbox.style.display = 'none';
            lightboxImg.src = '';
        }
    });
});
