document.addEventListener('DOMContentLoaded', function() {
    const loadingScreen = document.querySelector('.loading-screen');
    const body = document.body;
      if (loadingScreen) {
        loadingScreen.style.display = 'flex';
        body.style.overflow = 'hidden';
        body.style.position = 'fixed';
        body.style.width = '100%';
        body.style.height = '100%';
          function hideLoadingScreen() {
            loadingScreen.style.opacity = '0';
            loadingScreen.style.transition = 'opacity 0.8s ease-out';
            
            setTimeout(() => {
                loadingScreen.style.display = 'none';
                loadingScreen.style.visibility = 'hidden';
                loadingScreen.style.zIndex = '-1';
                body.style.overflow = 'auto';
            }, 500);
        }
          window.addEventListener('load', function() {
              setTimeout(hideLoadingScreen, 500);
        });
          setTimeout(hideLoadingScreen, 3000);
          loadingScreen.addEventListener('click', hideLoadingScreen);
    }
});
