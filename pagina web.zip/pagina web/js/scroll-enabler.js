document.addEventListener('DOMContentLoaded', function() {
      document.documentElement.style.overflow = 'auto';
    document.documentElement.style.overflowY = 'scroll';
    document.body.style.overflow = 'auto';
    document.body.style.overflowY = 'scroll';
    document.body.style.height = 'auto';
    document.documentElement.style.height = '100%';
      document.body.style.touchAction = 'auto';
    document.documentElement.style.touchAction = 'auto';
    
    console.log('Scroll forzado habilitado');
});
  function forceScrollEnable() {
      const allElements = document.querySelectorAll('*');
    allElements.forEach(el => {
        const styles = window.getComputedStyle(el);
        if (styles.overflow === 'hidden' || styles.overflowY === 'hidden') {
            if (el === document.body || el === document.documentElement) {
                el.style.overflow = 'auto !important';
                el.style.overflowY = 'scroll !important';
            }
        }
    });
      document.body.style.setProperty('overflow', 'auto', 'important');
    document.body.style.setProperty('overflow-y', 'scroll', 'important');
    document.documentElement.style.setProperty('overflow', 'auto', 'important');
    document.documentElement.style.setProperty('overflow-y', 'scroll', 'important');
      document.body.classList.remove('no-scroll', 'overflow-hidden');
    document.documentElement.classList.remove('no-scroll', 'overflow-hidden');
}
  let attempts = 0;
const forceInterval = setInterval(() => {
    forceScrollEnable();
    attempts++;
    if (attempts >= 10) {
        clearInterval(forceInterval);
    }
}, 1000);
  forceScrollEnable();
  document.addEventListener('keydown', function(e) {
    if (e.key === 'ArrowDown' || e.key === ' ') {
        e.preventDefault();
        window.scrollBy(0, 100);
    }
    if (e.key === 'ArrowUp') {
        e.preventDefault();
        window.scrollBy(0, -100);
    }
    if (e.key === 'PageDown') {
        e.preventDefault();
        window.scrollBy(0, window.innerHeight);
    }
    if (e.key === 'PageUp') {
        e.preventDefault();
        window.scrollBy(0, -window.innerHeight);
    }
});
